// src/config.js
export const API_URL = "http://localhost:3001"; // URL base de la API
export const TIMEOUT = 5000; // Tiempo de espera para las solicitudes               