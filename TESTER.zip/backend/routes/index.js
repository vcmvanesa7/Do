export { authRouter } from './authRoutes.js';
export { levelsRouter } from './levelsRoutes.js';
export { exercisesRouter } from './exercisesRouter.js';